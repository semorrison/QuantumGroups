BeginPackage["QuantumGroups`Data`B2`MatrixPresentations`", {"QuantumGroups`", "QuantumGroups`MatrixPresentations`", "QuantumGroups`Utilities`MatrixWrapper`", "QuantumGroups`Algebra`"}]
Message[QuantumGroups::loading,"QuantumGroups`Data`B2`MatrixPresentations`"]

Begin["`Private`"]
q=Global`q;
MatrixPresentation[Subscript[B, 2]][SuperPlus[Subscript[X, 1]]][Irrep[Subscript[B, 2]][{1, 0}], FundamentalBasis, {0, 0}]:=Matrix[0, 1, {}]

End[]
EndPackage[]