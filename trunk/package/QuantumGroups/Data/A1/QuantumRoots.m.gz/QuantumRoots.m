BeginPackage["QuantumGroups`Data`A1`QuantumRoots`", {"QuantumGroups`"}]
Message[QuantumGroups::loading,"QuantumGroups`Data`A1`QuantumRoots`"]

Begin["`Private`"]
q=Global`q;

End[]
EndPackage[]